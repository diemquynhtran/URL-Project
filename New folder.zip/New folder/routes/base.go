package routes

/*
func (s *Server) InitializeRoutes() {

}
*/

